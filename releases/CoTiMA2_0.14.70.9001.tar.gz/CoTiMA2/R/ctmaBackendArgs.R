#' Backend-specific default arguments
#'
#' Return a fresh named list of backend controls. Stan remains CoTiMA's
#' default backend. During the compatibility phase, the Stan result is
#' identical in value to the deprecated \code{CoTiMAStanctArgs} snapshot;
#' Julia defaults are grouped by the public
#' workflow and estimation method that uses them.
#'
#' Model-construction controls such as time scaling and TI-predictor scaling
#' remain top-level CoTiMA arguments. \code{backendArgs} is intended only for
#' controls of the selected estimation engine.
#'
#' Calling \code{ctmaBackendDefaults()} without arguments returns the
#' \code{"stan"} defaults; it does not display defaults for every backend.
#' Request another backend explicitly, for example
#' \code{ctmaBackendDefaults("ctsemjulia", "ML", "ctmaFit")}. Stan has no
#' separate \code{uncertainty} entry in this list: Bayesian uncertainty comes
#' from posterior draws, while optimized Stan fits use ctsem's corresponding
#' estimation machinery. CoTiMA2's own \code{"julia"} backend exposes
#' \code{uncertainty} directly. For \code{"ctsemjulia"}, CoTiMA2 explicitly
#' returns \code{optimcontrol$uncertainty = "hessian"}, an explicit CoTiMA2 choice. Current ctsem 4.x instead defaults to
#' checked uncertainty. This makes the effective default visible and gives regular
#' ML fits standard errors and intervals. Fast development diagnostics can
#' deliberately skip post-fit uncertainty with
#' \code{backendArgs = list(optimcontrol = list(estonly = TRUE))}.
#'
#' @param backend Estimation backend: \code{"stan"} (the default),
#'   \code{"julia"} for CoTiMA2's Julia engine, or experimental
#'   \code{"ctsemjulia"} for ctsem's native Julia engine. It supports ML and,
#'   with a compatible ctsem 4.x development version, Bayesian sampling with
#'   NUTS, SAEM, learned-map NUTS, or tempered SMC. NULL sampling defaults
#'   leave selection and tuning to ctsem. \code{intoverpop="auto"} delegates
#'   integration to ctsem; \code{"none"} requests joint random-effects
#'   sampling and \code{"laplace"} or \code{"augmented"} requests a marginal.
#' \code{"quadrature"} explicitly refines an optimized native Laplace fit with random effects. It is not a posterior sampler. Support requires a compatible recent ctsem version.
#' @param estimation Estimation method. For
#'   \code{workflow = "ctmaJuliaFit"}, use \code{"ML"} or \code{"Bayes"};
#'   \code{"none"} returns the common Julia evaluation controls.
#'   \code{workflow = "ctmaReFit"} currently supports Julia defaults only for
#'   \code{"Bayes"}. This argument is ignored for the compatibility Stan list.
#' @param workflow Public workflow for which defaults are requested. The
#'   current Julia workflows are \code{"ctmaJuliaFit"}, \code{"ctmaInit"},
#'   \code{"ctmaFit"}, \code{"ctmaAllInvFit"}, \code{"ctmaEqual"}, and
#'   \code{"ctmaReFit"}.
#'
#' @return A fresh named list of backend-specific defaults.
#' @export
#'
#' @examples
#' ctmaBackendDefaults()
#' ctmaBackendDefaults("julia", "ML", "ctmaJuliaFit")
#' ctmaBackendDefaults("julia", "Bayes", "ctmaReFit")
#' ctmaBackendDefaults("ctsemjulia", "ML", "ctmaFit")
#' ctmaBackendDefaults("ctsemjulia", "Bayes", "ctmaFit")
ctmaBackendDefaults <- function(
    backend = c("stan", "julia", "ctsemjulia"),
    estimation = NULL,
    workflow = c("ctmaJuliaFit", "ctmaFit", "ctmaInit", "ctmaAllInvFit",
                 "ctmaEqual", "ctmaReFit")) {
  if (missing(workflow) && identical(tolower(backend[1L]), "ctsemjulia")) {
    workflow <- "ctmaFit"
  }
  backend <- match.arg(
    tolower(backend), c("stan", "julia", "ctsemjulia")
  )

  if (identical(backend, "stan")) {
    return(.ctmaStanBackendDefaults())
  }

  if (identical(backend, "ctsemjulia")) {
    workflow <- workflow[1L]
    if (!workflow %in% c("ctmaFit", "ctmaInit")) stop(
      "backend = 'ctsemjulia' is currently available only for ctmaFit() ",
      "and ctmaInit().",
      call. = FALSE
    )
    if (is.null(estimation)) estimation <- "ml"
    estimation <- match.arg(tolower(estimation), c("ml", "bayes"))
    if (identical(estimation, "ml")) {
      common <- list(
        inits = NULL,
        intoverpop = "auto",
        stationary = FALSE,
        optimcontrol = list(uncertainty = "hessian"),
        priors = NULL,
        verbose = NULL
      )
    } else {
      common <- list(
        inits = NULL,
        intoverpop = "auto",
        stationary = FALSE,
        optimcontrol = list(),
        priors = NULL,
        verbose = NULL,
        sampleControl = list(
          sampler = NULL,
          placement = NULL,
          chains = NULL,
          warmup = NULL,
          draws = NULL,
          maxDraws = NULL,
          processes = NULL,
          seed = NULL,
          minESS = NULL,
          meanESS = NULL,
          rhatTarget = NULL,
          saveEffects = NULL
        )
      )
    }
    if (identical(workflow, "ctmaInit")) return(common)
    return(c(list(
      study_id = NULL,
      study_id_ti = NULL,
      study_dummy_ti = NULL,
      study_random_effects = NULL,
      study_covariance = "full",
      subject_random_effects = NULL,
      study_parameters = NULL,
      subject_parameters = NULL,
      reDRIFT = NULL,
      reDIFFUSION = NULL,
      reT0VAR = NULL,
      remove_study_fixed_effects = TRUE,
      sdscale_study = 1
    ), common))
  }

  workflow <- match.arg(workflow)
  if (is.null(estimation)) {
    estimation <- if (identical(workflow, "ctmaReFit")) "bayes" else "ml"
  }
  estimation <- match.arg(tolower(estimation), c("none", "ml", "bayes"))

  if (identical(workflow, "ctmaReFit")) {
    if (!identical(estimation, "bayes")) {
      stop(
        "Julia backend defaults for ctmaReFit currently support only ",
        "estimation = 'Bayes'.",
        call. = FALSE
      )
    }
    return(list(
      julia_file = system.file("julia", "CtsemJulia.jl", package = "CoTiMA2"),
      initialize = TRUE,
      julia_home = NULL,
      julia_threads = 1L,
      blas_threads = 1L,
      warmup = 1000L,
      samples = 1000L,
      target_accept = 0.9,
      max_depth = 8L,
      metric = "dense",
      chunksize = 7L,
      parallel_chains = 1L,
      threads_per_chain = NULL,
      nuts_progress = TRUE,
      progress_every = 25L
    ))
  }

  common <- list(
    compute = NULL,
    julia_file = NULL,
    initialize = TRUE,
    julia_home = NULL,
    validate = TRUE,
    tolerance = 1e-6,
    chunksize = 7L,
    inits = NULL,
    seed = NULL,
    performance_warning = TRUE,
    show_trace = TRUE,
    julia_threads = "auto",
    subject_threads = "auto",
    blas_threads = 1L
  )
  if (identical(estimation, "none")) return(common)

  if (identical(estimation, "ml")) {
    result <- c(common, list(
      uncertainty = TRUE,
      maxiters = 5000L,
      gradient_tolerance = 1e-3,
      function_relative_tolerance = 0,
      parameter_relative_tolerance = 0,
      optimizer_initial_step = 0.01,
      multistart = 1L,
      parallel_starts = 1L,
      threads_per_start = NULL,
      multistart_jitter = 0.1,
      warm_start = "auto",
      warm_start_fraction = 0.10,
      warm_start_subjects_per_parameter = 20L,
      warm_start_minimum_per_study = 25L,
      warm_start_maximum_subjects = 5000L,
      warm_start_binary_minimum = 20L,
      warm_start_maxiters = 250L,
      carefulFit = TRUE,
      confidence = 0.95,
      transformed = TRUE,
      transformed_draws = 1000L,
      transformed_cores = 1L
    ))
    if (workflow %in% c("ctmaFit", "ctmaInit", "ctmaAllInvFit", "ctmaEqual")) {
      result$uncertainty <- TRUE
      result$transformed <- TRUE
    }
    if (identical(workflow, "ctmaInit")) {
      result$maxiters <- 5000L
      result$gradient_tolerance <- 0.005
    }
    return(result)
  }

  c(common, list(
    chains = 4L,
    warmup = 1000L,
    samples = 1000L,
    target_accept = 0.8,
    max_depth = 10L,
    metric = "diagonal",
    init_jitter = 0.01,
    nuts_progress = TRUE,
    parallel_chains = 1L,
    threads_per_chain = NULL,
    transformed = TRUE,
    transformed_draws = 1000L,
    transformed_cores = 1L
  ))
}

.ctmaResourceInteger <- function(value, name, minimum = 1L) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value != floor(value) || value < minimum || value > .Machine$integer.max)
    stop("'", name, "' must be one integer >= ", minimum, ".", call. = FALSE)
  as.integer(value)
}

.ctmaAvailableCores <- function(omit = 0L) {
  omit <- .ctmaResourceInteger(omit, "omit", 0L)
  # parallelly respects affinity, scheduler/cgroup limits and R check limits.
  detected <- tryCatch(parallelly::availableCores(omit = omit)[1L],
    error = function(e) 1L)
  if (!is.numeric(detected) || length(detected) != 1L ||
      !is.finite(detected) || detected < 1L) return(1L)
  as.integer(detected)
}

.ctmaCheckJuliaBudget <- function(pool, workers = 1L, per_worker = pool,
    blas = 1L, budget = .ctmaAvailableCores()) {
  pool <- .ctmaResourceInteger(pool, "julia_threads")
  workers <- .ctmaResourceInteger(workers, "parallel workers")
  per_worker <- .ctmaResourceInteger(per_worker, "threads per worker")
  blas <- .ctmaResourceInteger(blas, "blas_threads")
  budget <- .ctmaResourceInteger(budget, "CPU budget")
  # Placement/main and worker phases are sequential, not simultaneous.
  demand <- max(as.double(pool), as.double(workers) * per_worker) * blas
  if (demand > budget) stop("Julia/BLAS configuration requests up to ", demand,
    " CPU threads but the resolved CPU budget is ", budget,
    ". Reduce parallel workers, Julia threads or blas_threads.", call. = FALSE)
  invisible(demand)
}

.ctmaLimitThreadEnvironment <- function() {
  keys <- c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
    "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
  old <- Sys.getenv(keys, unset = NA_character_)
  do.call(Sys.setenv, as.list(stats::setNames(rep("1", length(keys)), keys)))
  function() {
    absent <- is.na(old)
    if (any(absent)) Sys.unsetenv(keys[absent])
    if (any(!absent)) do.call(Sys.setenv, as.list(old[!absent]))
  }
}

.ctmaResolveJuliaThreads <- function(value, available = .ctmaAvailableCores()) {
  if (is.character(value) && length(value) == 1L &&
      identical(tolower(value), "auto")) {
    return(max(1L, as.integer(available) - 1L))
  }
  resolved <- .ctmaResourceInteger(value, "julia_threads")
  if (resolved > available) stop("'julia_threads' exceeds the available CPU budget (",
    available, ").", call. = FALSE)
  resolved
}

.ctmaResolveSubjectThreads <- function(value, julia_threads) {
  if (is.null(value) || (is.character(value) && length(value) == 1L &&
      identical(tolower(value), "auto"))) return(as.integer(julia_threads))
  resolved <- .ctmaResourceInteger(value, "subject_threads")
  min(resolved, as.integer(julia_threads))
}

.ctmaResolveCores <- function(
    coresToUse, backend = c("stan", "julia", "ctsemjulia"), task_count = NULL,
    max_stan_workers = 32L, announce = TRUE, workflow = "CoTiMA") {
  backend <- match.arg(
    tolower(backend), c("stan", "julia", "ctsemjulia")
  )
  detected <- .ctmaAvailableCores()
  requested <- .ctmaResourceInteger(coresToUse, "coresToUse", -.Machine$integer.max)
  if (requested < 0L) requested <- detected + requested
  if (requested == 0L) requested <- 1L
  resolved <- min(max(1L, requested), detected)
  reason <- character()
  if (!is.null(task_count)) {
    task_count <- suppressWarnings(as.integer(task_count)[1L])
    if (!is.na(task_count) && task_count > 0L && identical(backend, "stan") &&
        resolved > task_count) {
      resolved <- task_count
      reason <- c(reason, "number of parallel tasks")
    }
  }
  max_stan_workers <- suppressWarnings(as.integer(max_stan_workers)[1L])
  if (identical(backend, "stan") && !is.na(max_stan_workers) &&
      max_stan_workers > 0L && resolved > max_stan_workers) {
    resolved <- max_stan_workers
    reason <- c(reason, "safe R-worker limit")
  }
  if (isTRUE(announce) && (resolved != requested || length(reason))) {
    message(
      "Note: ", workflow, " resolved coresToUse=", coresToUse, " to ",
      resolved, " ", if (identical(backend, "stan")) "Stan/R worker" else "Julia thread",
      "(s)", if (length(reason)) paste0(" (limited by ", paste(reason, collapse = " and "), ")") else "", "."
    )
  }
  list(
    requested = as.integer(coresToUse)[1L], resolved = resolved,
    available = detected, backend = backend, reasons = reason
  )
}

.ctmaValidateBackendArgs <- function(defaults, overrides = NULL,
    path = "backendArgs") {
  if (is.null(overrides)) return(invisible(TRUE))
  if (!is.list(overrides) || (length(overrides) &&
      (is.null(names(overrides)) || anyNA(names(overrides)) ||
        any(names(overrides) == "")))) {
    stop(path, " must be a fully named list.", call. = FALSE)
  }

  unknown <- setdiff(names(overrides), names(defaults))
  if (length(unknown)) {
    stop(
      "Unknown ", path, ": ", paste(unknown, collapse = ", "),
      call. = FALSE
    )
  }

  nested <- intersect(names(overrides), names(defaults))
  for (name in nested) {
    if (is.list(defaults[[name]]) && !is.null(overrides[[name]])) {
      .ctmaValidateBackendArgs(
        defaults[[name]], overrides[[name]],
        path = paste0(path, "$", name)
      )
    }
  }
  invisible(TRUE)
}

.ctmaMergeBackendArgs <- function(defaults, overrides = NULL,
    path = "backendArgs") {
  if (!is.list(defaults) || is.null(names(defaults)) ||
      anyNA(names(defaults)) || any(names(defaults) == "")) {
    stop("Backend defaults must be a fully named list.", call. = FALSE)
  }
  .ctmaValidateBackendArgs(defaults, overrides, path = path)
  if (is.null(overrides)) return(defaults)
  utils::modifyList(defaults, overrides, keep.null = TRUE)
}

.ctmaBoundCtFitResources <- function(args) {
  # `$cores` also matches `coreset`: resource keys must be exact.
  cores <- args[["cores", exact = TRUE]]
  if (is.null(cores)) return(args)
  args[["cores"]] <- .ctmaResolveCores(cores, backend = "ctsemjulia",
    announce = FALSE)$resolved
  control <- args[["optimcontrol", exact = TRUE]]
  nested <- control[["cores", exact = TRUE]]
  if (!is.null(nested)) {
    control[["cores"]] <- min(args[["cores"]],
      .ctmaResourceInteger(nested, "optimcontrol$cores"))
    args[["optimcontrol"]] <- control
  }
  args
}
