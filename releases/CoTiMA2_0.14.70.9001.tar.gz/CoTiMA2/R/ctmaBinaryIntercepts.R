# Validate and normalize user-supplied location parameter specifications.
.ctma_normalize_location_specs <- function(cint, manifestMeans,
    nlatent, nmanifest) {
  nlatent <- as.integer(nlatent)[1L]
  nmanifest <- as.integer(nmanifest)[1L]
  if (is.na(nlatent) || nlatent < 1L || is.na(nmanifest) || nmanifest < 1L) {
    stop("Latent and manifest dimensions must be positive integers.",
      call. = FALSE)
  }
  # Keep scalar zero scalar because ctmaLabels handles that public shorthand;
  # the model constructors expand it to the required matrix dimensions.
  if (is.null(cint)) cint <- 0
  if (is.null(manifestMeans)) manifestMeans <- 0
  if (length(cint) > 1L && length(cint) != nlatent) stop(
    "You specified CINTs, but their length does not correspond to the ",
    "number of latent variables.", call. = FALSE)
  if (length(manifestMeans) > 1L && length(manifestMeans) != nmanifest) stop(
    "You specified manifestMeans, but their length does not correspond to ",
    "the number of manifest variables.", call. = FALSE)
  list(cint = cint, manifestMeans = manifestMeans)
}

# Restore the requested observation families after a model-construction branch
# has replaced the original ctsem model (for example, the augmented-state
# random-intercept representation).
.ctma_restore_manifesttype <- function(model, binaries) {
  if (is.null(binaries)) return(model)
  nmanifest <- as.integer(model$n.manifest)[1L]
  if (!is.finite(nmanifest) || nmanifest < 1L || length(binaries) < nmanifest)
    stop("binaries must contain at least one entry per manifest variable.",
      call. = FALSE)
  model$manifesttype <- as.numeric(binaries[seq_len(nmanifest)])
  model
}

# Translate ctsem's individually varying intercept branch to CoTiMA's
# Julia-compatible augmented-state representation. The pooled flag distinguishes
# the restricted model from randomIntercepts, whose covariance structure may
# vary between studies.
.ctma_julia_pooled_intercepts <- function(indVarying, randomIntercepts,
    backend, announce = TRUE, workflow = "ctmaFit") {
  pooled <- identical(backend, "julia") &&
    identical(randomIntercepts, FALSE) &&
    indVarying %in% c("CINT", "MANIFEST")
  if (!pooled) return(list(
    indVarying = indVarying,
    randomIntercepts = randomIntercepts,
    pooled = FALSE
  ))

  representation <- indVarying
  if (isTRUE(announce)) message(
    "Note: For ", workflow, "(backend='julia'), indVarying='",
    representation, "' is represented by Julia-compatible latent phantom ",
    "processes with one pooled random-intercept covariance matrix."
  )
  list(
    indVarying = FALSE,
    randomIntercepts = representation,
    pooled = TRUE
  )
}

# In the augmented model, retain the freely estimated baseline covariance of
# the phantom intercepts but remove every TI effect on covariance parameters
# involving a phantom state. Phantom means and their TI effects are deliberately
# left untouched: this separation also provides a clean extension point for a
# future study-random-effects/Laplace layer.
.ctma_pool_phantom_covariance <- function(model, original_nlatent) {
  if (is.null(model$pars) || !is.data.frame(model$pars)) stop(
    "The ctsem model has no parameter table to pool phantom covariances.",
    call. = FALSE)
  original_nlatent <- as.integer(original_nlatent)[1L]
  pars <- model$pars
  phantom_covariance <- !is.na(pars$matrix) & pars$matrix == "T0VAR" &
    ((!is.na(pars$row) & pars$row > original_nlatent) |
       (!is.na(pars$col) & pars$col > original_nlatent))
  effect_columns <- grep("_effect$", names(pars), value = TRUE)
  if (any(phantom_covariance) && length(effect_columns)) {
    model$pars[phantom_covariance, effect_columns] <- FALSE
  }
  model
}

# Validate location parameters for binary manifest variables using the final
# ctsem parameter table. A CINT counts only when it is connected to the
# manifest variable through an active loading.
.ctma_check_binary_intercepts <- function(model, binaries,
    process_intercepts = FALSE, inform = TRUE, study_label = "") {
  if (is.null(binaries)) return(invisible(model))
  if (is.null(model$pars) || !is.data.frame(model$pars)) stop(
    "The ctsem model has no parameter table for binary-intercept validation.",
    call. = FALSE)

  nmanifest <- as.integer(model$n.manifest)[1L]
  nlatent <- as.integer(model$n.latent)[1L]
  if (!is.finite(nmanifest) || nmanifest < 1L ||
      !is.finite(nlatent) || nlatent < 1L) stop(
    "The ctsem model does not report valid manifest and latent dimensions.",
    call. = FALSE)
  if (length(binaries) != nmanifest) stop(
    "binaries must contain exactly one entry per manifest variable.",
    call. = FALSE)
  binary_manifest <- which(as.integer(binaries) == 1L)
  if (!length(binary_manifest))
    return(invisible(model))

  pars <- model$pars
  free_by_row <- function(matrix_name, nr) {
    answer <- rep(FALSE, nr)
    selected <- pars[!is.na(pars$matrix) & pars$matrix == matrix_name,
      , drop = FALSE]
    if (!nrow(selected)) return(answer)
    for (i in seq_len(nrow(selected))) {
      r <- as.integer(selected$row[i])
      if (!is.na(r) && r >= 1L && r <= nr)
        answer[r] <- answer[r] || !is.na(selected$param[i])
    }
    answer
  }

  manifest_mean_free <- free_by_row("MANIFESTMEANS", nmanifest)
  cint_free <- free_by_row("CINT", nlatent)
  lambda_active <- matrix(FALSE, nmanifest, nlatent)
  lambda <- pars[!is.na(pars$matrix) & pars$matrix == "LAMBDA",
    , drop = FALSE]
  if (nrow(lambda)) for (i in seq_len(nrow(lambda))) {
    r <- as.integer(lambda$row[i]); cc <- as.integer(lambda$col[i])
    if (is.na(r) || is.na(cc) || r < 1L || r > nmanifest ||
        cc < 1L || cc > nlatent) next
    is_free <- !is.na(lambda$param[i])
    is_fixed_nonzero <- !is.na(lambda$value[i]) && lambda$value[i] != 0
    lambda_active[r, cc] <- is_free || is_fixed_nonzero
  }
  cint_support <- vapply(seq_len(nmanifest), function(j)
    any(lambda_active[j, ] & cint_free), logical(1L))

  has_cint <- cint_support[binary_manifest]
  has_manifest_mean <- manifest_mean_free[binary_manifest]
  labels <- model$manifestNames
  if (is.null(labels) || length(labels) < nmanifest)
    labels <- paste0("manifest ", seq_len(nmanifest))
  describe <- function(index) paste(labels[index], collapse = ", ")

  fixed_zero <- function(family, rows) {
    cells <- pars[pars$matrix == family & pars$row %in% rows, , drop = FALSE]
    all(is.na(cells$param) & !is.na(cells$value) & cells$value == 0)
  }
  zero <- vapply(binary_manifest, function(j) {
    linked <- which(lambda_active[j, ])
    # Dynamic phantom intercepts can enter through a nonzero DRIFT column.
    drift <- pars[pars$matrix == "DRIFT", , drop = FALSE]
    active <- !is.na(drift$param) | (!is.na(drift$value) & drift$value != 0)
    repeat {
      expanded <- union(linked, drift$col[active & drift$row %in% linked])
      if (length(expanded) == length(linked)) break
      linked <- expanded
    }
    fixed_zero("MANIFESTMEANS", j) && fixed_zero("T0MEANS", linked) &&
      fixed_zero("CINT", linked)
  }, logical(1))
  if (any(zero)) warning(study_label, "Binary indicator(s) ",
    describe(binary_manifest[zero]), ": MANIFESTMEANS and connected T0MEANS ",
    "and CINT are fixed at zero. Check whether a free location parameter ",
    "is needed for the observed prevalence.", call. = FALSE)
  if (isTRUE(process_intercepts)) return(invisible(model))

  manifest_only <- !has_cint & has_manifest_mean
  if (isTRUE(inform) && any(manifest_only)) message(
    "Binary variable(s) ", describe(binary_manifest[manifest_only]),
    " use freely estimated MANIFESTMEANS while their connected latent CINTs ",
    "are fixed.")

  both <- has_cint & has_manifest_mean
  if (isTRUE(inform) && any(both)) warning(
    "Binary variable(s) ", describe(binary_manifest[both]),
    " have both freely estimated MANIFESTMEANS and connected CINT ",
    "parameters. Check location identification; normally one should be fixed.",
    call. = FALSE)
  invisible(model)
}

.ctma_named_location <- function(x, labels, argument) {
  if (is.null(names(x))) return(NULL)
  if (anyNA(names(x)) || anyDuplicated(names(x)) ||
      !setequal(names(x), labels))
    stop(argument, " must name every model variable exactly once: ",
         paste(labels, collapse = ", "), call. = FALSE)
  values <- x[labels]
  if (!all(vapply(values, function(v)
    length(v) == 1L && !is.na(v) &&
      ((is.numeric(v) && is.finite(v)) ||
       (is.character(v) && nzchar(v) && v != "auto")), logical(1))))
    stop(argument, " entries must be finite numbers or free parameter labels.",
         call. = FALSE)
  unname(unlist(values))
}

.ctma_select_phantom_intercepts <- function(drift, lambda, covariance, means,
    nlatent, family, spec) {
  active <- is.na(suppressWarnings(as.numeric(spec)))
  phantom <- nlatent + seq_len(nlatent)
  if (family == "MANIFEST") {
    if (nrow(lambda) != nlatent && any(active))
      stop("Named phantom manifest intercepts require equal manifest and latent dimensions.")
    lambda[, phantom] <- 0
    if (any(active)) lambda[cbind(which(active), phantom[active])] <- 1
    means[phantom] <- 0
  } else {
    means[phantom] <- spec
    # A fixed CINT still contributes to the dynamic state through its mean.
  }
  fixed <- phantom[!active]
  covariance[fixed, ] <- 0
  covariance[, fixed] <- 0
  list(drift = drift, lambda = lambda, covariance = covariance, means = means)
}
